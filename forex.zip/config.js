var config = {};

config.token = "8ba8034e957d50a820b3bb8b4b60e85714e5d869"; //
config.trading_api_host = 'api-demo.fxcm.com';
config.trading_api_port = 443;
config.trading_api_proto = 'https'; // http or https

module.exports = config;